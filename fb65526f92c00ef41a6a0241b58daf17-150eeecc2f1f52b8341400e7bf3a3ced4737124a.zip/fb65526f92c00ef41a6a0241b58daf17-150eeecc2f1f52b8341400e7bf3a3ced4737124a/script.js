window.onload = function(){
  
  var canvas = document.getElementById("canvas"),
      ctx = canvas.getContext("2d");
  
  var w = canvas.width = window.innerWidth * 2;
  var h = canvas.height = window.innerHeight * 2;

  var numParticles = 15,
      particles = [],
      radius = 10,
      speed = 0;

  function randomize(min, max) {
    return Math.round(Math.random() * (max - min) + min);
  }

  var pos = {
    x: w/2,
    y: h/2
  };

  var colors = ["#e67e22", "#e74c3c", "blue"];

  // clone object pos
  var accel = JSON.parse(JSON.stringify(pos));

  document.body.addEventListener("mousemove", function(e){
    pos.x = e.clientX;
    pos.y = e.clientY;
  });
  

  for(var i = 0; i < numParticles; i++){
    particles.push(new generate());
  }

  function generate(){
    this.x = pos.x;
    this.y = pos.y;
    this.radius = randomize(3,6);
    this.color = colors[Math.floor(Math.random() * colors.length)];
    this.vx = randomize(-2, 2);
    this.vy = randomize(1, 10);
    this.life = randomize(20, 40);
  }

  render();

  function render(){
    ctx.clearRect(0, 0, w, h);

    accel.x += (pos.x - accel.x) * .2;
    accel.y += (pos.y - accel.y) * .5;

    ctx.beginPath();
    ctx.fillStyle = "#f1c0f";
    ctx.arc(accel.x, accel.y, radius, 0, Math.PI * 2, false);
    ctx.fill();
    ctx.globalCompositeOperation = "xor";

    for(var j = 0; j < particles.length; j++){
      var p = particles[j];

      ctx.beginPath();
      ctx.fillStyle = p.color;
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2, false);
      ctx.fill();

      p.x += p.vx;
      p.y -= p.vy;

      p.radius -= 0.075;
      p.life--;

      if(p.life < 0 || p.radius < 0){
        particles[j] = new generate();
      }

    }

    requestAnimationFrame(render);
  }
};

window.onLoad = functionImage(){
  var projectElement = document.getElementByClass("projectShadow"),
      ctxImage = fireImage.getContext("2d");
 
  var wImage = fireImage.width = div.clientWidth * 2;
  var hImage = fireImage.height = div.clientHeight * 2;

  var numParticlesImage = 15,
      particlesImage = [],
      radiusImage = 10,
      speedImage = 0;

  function randomizeImage(min, max) {
    return Math.round(Math.random() * (max - min) + min);
  }

  var posImage = {
    x: wImage/2,
    y: hImage/2
  };

  var colorsImage = ["#e67e22", "#e74c3c", "blue"];

  // clone object posImage
  var accelImage = JSON.parse(JSON.stringify(posImage));

    posImage.x = e.clientX;
    posImage.y = e.clientY;
  });
 

  for(var iImage = 0; iImage < numParticlesImage; iImage++){
    particlesImage.push(new generateImage());
  }

  function generateImage(){
    this.x = posImage.x;
    this.y = posImage.y;
    this.radius = randomize(3,6);
    this.color = colorsImage[Math.floor(Math.random() * colorsImage.length)];
    this.vx = randomize(-2, 2);
    this.vy = randomize(1, 10);
    this.life = randomize(20, 40);
  }

  renderImage();

  function renderImage(){
    ctxImage.clearRect(0, 0, w, h);

    accelImage.x += (posImage.x - accelImage.x) * .2;
    accelImage.y += (posImage.y - accelImage.y) * .5;

    ctxImage.beginPath();
    ctxImage.fillStyle = "#f1c0f";
    ctxImage.arc(accelImage.x, accelImage.y, radius, 0, Math.PI * 2, false);
    ctxImage.fill();
    ctxImage.globalCompositeOperation = "xor";

    for(var jImage = 0; jImage < particlesImage.length; jImage++){
      var pImage = particlesImage[j];

      ctxImage.beginPath();
      ctxImage.fillStyle = p.color;
      ctxImage.arc(p.x, p.y, p.radius, 0, Math.PI * 2, false);
      ctxImage.fill();

      pImage.x += p.vx;
      pImage.y -= p.vy;

      pImage.radius -= 0.075;
      pImage.life--;

      if(pImage.life < 0 || pImage.radius < 0){
        particlesImage[j] = new generateImage();
      }

    }

    requestAnimationFrame(renderImage);
  }




  // credit

  
};